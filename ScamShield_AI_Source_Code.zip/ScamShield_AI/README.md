# ScamShield AI

A defensive cybersecurity prototype that analyses pasted messages and URLs using transparent heuristic rules. It does **not** visit URLs, submit user data to third parties, or guarantee that content is safe.

## Features
- Message and URL analysis
- Explainable warning indicators and 0–100 risk score
- Low / Medium / High risk bands
- SQLite scan history
- Health endpoint and JSON API
- Responsive dashboard UI

## Run locally
1. Install Python 3.10+.
2. Create and activate a virtual environment.
3. Install dependencies: `pip install -r requirements.txt`
4. Start the app: `python app.py`
5. Open `http://127.0.0.1:5000`

## API
`POST /api/analyze`
```json
{"type":"text","value":"Your account is blocked. Verify now and share your OTP."}
```
Use `"type":"url"` for URL analysis.
`GET /api/history` returns the latest ten scans.
`GET /health` checks service status.

## Test examples
- High-risk-style message: `URGENT! Your bank account is suspended. Verify now and share your OTP to claim your prize.`
- Lower-signal message: `The library meeting starts at 3 PM tomorrow.`
- URL: `http://secure-account-verify-login.example.top`

Use only synthetic examples in demonstrations. Do not paste private messages, passwords, OTPs, or real personal data.

## Limitations and responsible use
This is a student prototype based on simple keyword and URL-shape heuristics, not a trained AI model or production security scanner. It may produce false positives and false negatives. HTTPS does not mean a site is trustworthy, and suspicious-looking domain patterns are not proof of fraud. No external threat-intelligence feed, DNS lookup, browser isolation, or machine-learning model is connected.

## Suggested future work
- Integrate trusted URL reputation services with explicit consent and rate limits.
- Add multilingual message analysis and calibrated ML evaluation.
- Add authentication, role-based access, retention controls and deployment hardening.
- Evaluate on a labelled, privacy-safe dataset and report precision, recall and F1.
