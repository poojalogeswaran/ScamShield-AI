from flask import Flask, render_template, request, jsonify
from detector import analyze_text, analyze_url
from datetime import datetime, timezone
import sqlite3, os

app = Flask(__name__)
DB_PATH = os.environ.get("SCAMSHIELD_DB", "scans.db")

def init_db():
    with sqlite3.connect(DB_PATH) as con:
        con.execute("""CREATE TABLE IF NOT EXISTS scans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            scan_type TEXT NOT NULL,
            target TEXT NOT NULL,
            risk_level TEXT NOT NULL,
            score INTEGER NOT NULL,
            findings TEXT NOT NULL
        )""")

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/api/analyze", methods=["POST"])
def analyze():
    payload = request.get_json(silent=True) or {}
    kind = payload.get("type", "text")
    value = (payload.get("value") or "").strip()
    if not value:
        return jsonify({"error": "Enter a URL or message to analyse."}), 400
    if len(value) > 5000:
        return jsonify({"error": "Input is too long. Please keep it under 5,000 characters."}), 400
    result = analyze_url(value) if kind == "url" else analyze_text(value)
    created = datetime.now(timezone.utc).isoformat()
    with sqlite3.connect(DB_PATH) as con:
        con.execute(
            "INSERT INTO scans (created_at, scan_type, target, risk_level, score, findings) VALUES (?, ?, ?, ?, ?, ?)",
            (created, kind, value[:500], result["risk_level"], result["score"], " | ".join(result["findings"]))
        )
    return jsonify({**result, "created_at": created})

@app.route("/api/history")
def history():
    with sqlite3.connect(DB_PATH) as con:
        rows = con.execute(
            "SELECT id, created_at, scan_type, target, risk_level, score FROM scans ORDER BY id DESC LIMIT 10"
        ).fetchall()
    return jsonify([
        {"id": r[0], "created_at": r[1], "type": r[2], "target": r[3],
         "risk_level": r[4], "score": r[5]} for r in rows
    ])

@app.route("/health")
def health():
    return jsonify({"status": "ok", "service": "ScamShield AI"})

if __name__ == "__main__":
    init_db()
    app.run(host="127.0.0.1", port=5000, debug=True)
