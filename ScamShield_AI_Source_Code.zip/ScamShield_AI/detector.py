"""Explainable, heuristic-only detection for educational prototype use."""
import re
from urllib.parse import urlparse

URGENT = ["urgent", "immediately", "act now", "within 24 hours", "suspended", "blocked", "verify now"]
CREDENTIALS = ["password", "otp", "one time password", "pin", "cvv", "card number", "login details"]
REWARD = ["won", "winner", "prize", "lottery", "claim reward", "free gift"]
PAYMENT = ["payment failed", "refund", "bank account", "upi", "transfer money", "pay now"]
SHORTENERS = {"bit.ly", "tinyurl.com", "t.co", "is.gd", "cutt.ly", "rb.gy"}
SUSPICIOUS_TLDS = {".zip", ".top", ".click", ".work", ".country", ".gq", ".tk"}

def _level(score):
    if score >= 65: return "High"
    if score >= 35: return "Medium"
    return "Low"

def analyze_text(text):
    s = text.lower()
    score, findings = 0, []
    checks = [
        (URGENT, 15, "Urgency or pressure language detected"),
        (CREDENTIALS, 30, "Request for sensitive credentials or payment details detected"),
        (REWARD, 20, "Unexpected prize or reward language detected"),
        (PAYMENT, 20, "Payment, refund or money-transfer language detected"),
    ]
    for terms, points, message in checks:
        matches = [t for t in terms if t in s]
        if matches:
            score += points
            findings.append(message + " (" + ", ".join(matches[:3]) + ")")
    if re.search(r"https?://|www\.", s):
        score += 15
        findings.append("Message contains a web link; inspect the destination carefully")
    if re.search(r"\b\d{4,8}\b", s) and any(k in s for k in ["otp", "code", "verify"]):
        score += 15
        findings.append("A verification-code pattern appears alongside verification language")
    score = min(score, 100)
    if not findings:
        findings.append("No listed warning patterns were detected; this does not prove the message is safe")
    return {
        "score": score, "risk_level": _level(score), "findings": findings,
        "recommendations": _recommendations(score, findings),
        "disclaimer": "Heuristic prototype only. It cannot confirm whether a message is genuine or fraudulent."
    }

def analyze_url(value):
    raw = value.strip()
    if not re.match(r"^https?://", raw, re.I):
        raw = "https://" + raw
    parsed = urlparse(raw)
    host = (parsed.hostname or "").lower()
    score, findings = 0, []
    if not host or "." not in host:
        score += 45
        findings.append("The address does not look like a conventional public domain")
    if parsed.scheme != "https":
        score += 10
        findings.append("The URL does not use HTTPS")
    if host in SHORTENERS:
        score += 25
        findings.append("A URL-shortening service hides the final destination")
    if "@" in parsed.netloc:
        score += 25
        findings.append("An @ symbol appears in the URL authority and may disguise the destination")
    if len(host) > 35:
        score += 15
        findings.append("The domain name is unusually long")
    if host.count("-") >= 3:
        score += 10
        findings.append("The domain contains several hyphens")
    if any(host.endswith(tld) for tld in SUSPICIOUS_TLDS):
        score += 20
        findings.append("The domain uses a less-common top-level domain that deserves extra scrutiny")
    if re.search(r"(login|verify|secure|account|update|wallet|bank)", host):
        score += 10
        findings.append("The domain includes a security- or account-related keyword")
    score = min(score, 100)
    if not findings:
        findings.append("No listed URL warning patterns were detected; this does not prove the site is safe")
    return {
        "score": score, "risk_level": _level(score), "findings": findings,
        "recommendations": _recommendations(score, findings),
        "normalized_url": raw,
        "disclaimer": "This prototype does not visit the URL, check reputation feeds, or guarantee site safety."
    }

def _recommendations(score, findings):
    recs = []
    if score >= 35:
        recs.extend([
            "Do not enter passwords, OTPs, PINs, CVVs or banking details on an unverified page.",
            "Open the organisation's official app or type its known website address yourself.",
            "Verify unexpected requests using a trusted contact channel."
        ])
    else:
        recs.extend([
            "Check the sender and destination independently before taking action.",
            "Never share OTPs, passwords, PINs or CVVs with anyone."
        ])
    recs.append("If money has been lost or an account is at risk, contact your bank or service provider through its official channel.")
    return recs
