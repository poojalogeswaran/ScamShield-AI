let mode = "text";
const tabs = document.querySelectorAll(".tab");
const input = document.getElementById("payload");
const label = document.getElementById("input-label");
tabs.forEach(btn => btn.addEventListener("click", () => {
  tabs.forEach(t => t.classList.remove("selected"));
  btn.classList.add("selected"); mode = btn.dataset.type;
  label.textContent = mode === "url" ? "URL TO INSPECT" : "MESSAGE CONTENT";
  input.placeholder = mode === "url" ? "Example: http://secure-account-verify-login.example.top" : "Paste a suspicious message (use synthetic examples)...";
}));
document.getElementById("analyze").addEventListener("click", async () => {
  const error = document.getElementById("error"), result = document.getElementById("result"), button = document.getElementById("analyze");
  error.classList.add("hidden"); result.classList.add("hidden");
  if (!input.value.trim()) { error.textContent = "Please enter something to analyse."; error.classList.remove("hidden"); return; }
  button.disabled = true; button.textContent = "Analysing...";
  try {
    const res = await fetch("/api/analyze", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({type:mode,value:input.value})});
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Analysis failed.");
    document.getElementById("risk-title").textContent = data.risk_level + " risk detected";
    document.getElementById("risk-pill").textContent = data.risk_level.toUpperCase();
    document.getElementById("risk-pill").className = "risk-pill " + data.risk_level.toLowerCase();
    document.getElementById("score").textContent = data.score;
    document.getElementById("meter-fill").style.width = data.score + "%";
    document.getElementById("disclaimer").textContent = data.disclaimer;
    fillList("findings", data.findings); fillList("recommendations", data.recommendations);
    result.classList.remove("hidden"); loadHistory();
  } catch(e) { error.textContent = e.message; error.classList.remove("hidden"); }
  finally { button.disabled = false; button.innerHTML = 'Analyse risk <span>→</span>'; }
});
function fillList(id, values) { const ul=document.getElementById(id); ul.innerHTML=""; values.forEach(v=>{const li=document.createElement("li");li.textContent=v;ul.appendChild(li);}); }
async function loadHistory() {
  const body=document.getElementById("history-body");
  try {
    const res=await fetch("/api/history"), rows=await res.json();
    if (!rows.length) { body.innerHTML='<tr><td colspan="4" class="empty">No scans yet. Run an analysis to populate history.</td></tr>'; return; }
    body.innerHTML="";
    rows.forEach(r=>{const tr=document.createElement("tr");const vals=[r.type.toUpperCase(),r.target,r.risk_level,r.score];
      vals.forEach((v,i)=>{const td=document.createElement("td"); if(i===2){const span=document.createElement("span");span.className="tag "+v;span.textContent=v;td.appendChild(span);}else td.textContent=String(v).slice(0,i===1?55:100);tr.appendChild(td);});body.appendChild(tr);});
  } catch(e) { body.innerHTML='<tr><td colspan="4" class="empty">History is temporarily unavailable.</td></tr>'; }
}
document.getElementById("refresh").addEventListener("click",loadHistory);
loadHistory();
